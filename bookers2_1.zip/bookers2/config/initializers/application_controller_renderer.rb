# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f7dcbc1791ff8d1f856aba960659f38fdec6cc9355ffe3689314655bb4bf917c71a18377fbf020cc64a2e9b233b92b3a75c75f807a580667c9c451d0538b071f'
